
/* placementID:3281 */
tmntag.account('/10518929/tmn.thus/homepage');
tmntag.target({'site':'tmn.thus','partner':'n','oop':'true','ctype':'homepage','paid':'false'});


tmntag.placements=["3281"];

tmntag.adunit({account:'/10518929/tmn.thus/homepage/a0-p1-s9',div:'in_content',sizeMapping:[[[728,0],[[728,185],[728,200],[628,185]]],[[628,0],[[628,185]]],[[1,0],[[1,1]]],[[0,0],[]]],sizes:[[728,185],[728,200],[628,185]],targeting:{'_p':'1','_a':'0'}});
tmntag.adunit({account:'/10518929/tmn.thus/homepage/a1-p1-s0',div:'top_header',sizeMapping:[[[1000,0],[[1000,1]]], [[1,0],[[1,1]]], [[0,0],[]]],sizes:[[1000,1]],targeting:{'_p':'1','_a':'1'}});

try {
window.Purch=window.Purch||{};Purch.cs_data=Purch.cs_data||{};Purch.cs_data.country="NL";Purch.cs_data.page="https%3A%2F%2Fwww.tomshardware.com%2F";Purch.cs_data.page_domain="www.tomshardware.com";Purch.cs_data.user_ip="94.208.107.112";Purch.cs_data.UA="Chrome";Purch.cs_data.OS="Mac OS X";Purch.cs_data.device="Computer";Purch.cs_data.RID="2410704430678360820";Purch.cs_extradata=Purch.cs_extradata||{};Purch.cs_extradata.COOKIES="true";Purch.cs_extradata.COUNTRY="NL";
Purch.cs_extradata.PAGE="https%3A%2F%2Fwww.tomshardware.com%2F";Purch.cs_extradata.PAGE_DOMAIN="www.tomshardware.com";Purch.cs_extradata.USER_IP="94.208.107.112";Purch.cs_extradata.UA="Chrome";Purch.cs_extradata.OS="Mac OS X";Purch.cs_extradata.DEVICE="Computer";Purch.cs_extradata.RID="2410704430678360820";Purch.cs_extradata.VISITOR_ID="0d8866a42f2f49e3ae0ef55f5cbfe033";Purch.trimcsdata=function(a){for(var b in a)if(a[b]&&a[b]!=null&&a[b].indexOf("${")>=0)a[b]=undefined;return a};Purch.cs_data=Purch.trimcsdata(Purch.cs_data);
} catch (e) {
console.error(e);
}
if (typeof tmntag==='undefined') tmntag={};
tmntag.pubtargets = [];
tmntag.pubtargets.push(['oop', 'true']);
tmntag.pubtargets.push(['ctype', 'homepage']);
tmntag.pubtargets.push(['_rid', '2410704430678360820']);
tmntag.pubtargets.push(['_c', '1']);
tmntag.pubtargets.push(['paid', 'false']);
tmntag.pubtargets.push(['partner', 'n']);
tmntag.pubtargets.push(['site', 'tmn.thus']);
tmntag.pubtargets.push(['TUUID', '0d8866a42f2f49e3ae0ef55f5cbfe033']);
tmntag.pubtargets.push(['_rid', '2410704430678360820']);
tmntag.pubtargets.push(['kw', 'homepage']);
tmntag.pubtargets.push(['_pgid', '835c437e']);
tmntag.pubtargets.push(['mcat', ['p12']]);
tmntag.pubtargets.push(['scat', ['i328']]);
tmntag.pubtargets.push(['agents', ['kubqmf', '7wex2n']]);
tmntag.pubtargets.push(['urlhash', 'B5x4Ir7Kjw0']);
tmntag.pubtargets.push(['fr', 'false']);
tmntag.pubtargets.push(['adt', 'veryLow']);
tmntag.pubtargets.push(['alc', 'veryLow']);
tmntag.pubtargets.push(['dlm', 'veryLow']);
tmntag.pubtargets.push(['drg', 'veryLow']);
tmntag.pubtargets.push(['hat', 'veryLow']);
tmntag.pubtargets.push(['off', 'veryLow']);
tmntag.pubtargets.push(['vio', 'veryLow']);
tmntag.pubtargets.push(['_chnl', 'WEB']);
tmntag.markups=tmntag.markups||[];
tmntag.markupsInfo=tmntag.markupsInfo||[];
tmntag.adtargets=[];
tmntag.adtargets['in_content']=[];
tmntag.adtargets['in_content'].push(['_wb', '3']);
tmntag.adtargets['in_content'].push(['adunit', 'in_content']);
tmntag.adtargets['in_content'].push(['_p', '1']);
tmntag.adtargets['in_content'].push(['_a', '0']);
tmntag.adtargets['top_header']=[];
tmntag.adtargets['top_header'].push(['_wb', '4']);
tmntag.adtargets['top_header'].push(['adunit', 'top_header']);
tmntag.adtargets['top_header'].push(['_p', '1']);
tmntag.adtargets['top_header'].push(['_a', '1']);
tmntag.adtargets['in_content']=tmntag.adtargets['in_content']||[];
tmntag.adtargets['top_header']=tmntag.adtargets['top_header']||[];
tmntag.adtargets['in_content'].push(['id', 'd23fff3a-353c-11e9-951f-98f2b3ea1938']);
tmntag.adtargets['in_content'].push(['vw', ['40']]);
tmntag.adtargets['in_content'].push(['grm', ['40']]);
tmntag.adtargets['in_content'].push(['pub', ['40']]);
tmntag.adtargets['top_header'].push(['id', 'd23fff3b-353c-11e9-951f-98f2b3ea1938']);
tmntag.adtargets['top_header'].push(['vw', ['40']]);
tmntag.adtargets['top_header'].push(['grm', ['40']]);
tmntag.adparams=tmntag.adparams||{};
tmntag.adparams['in_content']=tmntag.adparams['in_content']||{};
tmntag.adparams['in_content']['ad_label_display']='report';
tmntag.adparams['in_content']['ad_label_position']='top_center';
tmntag.adparams['in_content']['adunit_style']='text-align:center;';
tmntag.adparams['in_content']['ad_label_style']='background-color:transparent !important;';
tmntag.adparams['top_header']=tmntag.adparams['top_header']||{};
tmntag.adparams['top_header']['adunit_style']='text-align:center;';
tmntag.adparams['top_header']['sort_heights']='true';
tmntag.pubtargets.push(['_sw1440', '1']);
tmntag.pubtargets.push(['_sh640', '1']);
tmntag.ircontext=tmntag.ircontext||{};
tmntag.ircontext['nuv'] = 10;
tmntag.pubtargets.push(['_ex', '|78|4|104|120|']);
tmntag.pubtargets.push(['_plc', ['3281']]);
if(typeof window.context=="undefined"||!window.context)top.window.requestid="2410704430678360820";if(typeof window.context=="undefined"||!window.context)top.window.experiments="|78|4|104|120|";tmntag.processTmntagResponse();try {
(function(){var a="18904";if(a==""||a.indexOf("$")==0)a="20915";window.bk_async=function(){var c="0d8866a42f2f49e3ae0ef55f5cbfe033";if(c!=""&&c.indexOf("$")!=0)bk_addPageCtx("pid","0d8866a42f2f49e3ae0ef55f5cbfe033");BKTAG.doTag(a,4)};(function(){var a=encodeURIComponent(document.referrer?document.referrer:""),d=document.getElementsByTagName("script")[0],b=document.createElement("script");b.async=true;b.src="//tags.bkrtx.com/js/bk-coretag.js?referer="+a;d.parentNode.insertBefore(b,d)})()})();
} catch (e) {
console.error(e);
}
try {
!function(){if(document.querySelector(".trending-wrapper"))return;var b=[{label:"Raspberry Pi 4",url:"https://www.tomshardware.com/news/raspberry-pi-4-everything-we-know,38539.html"},{label:"Ryzen 3000 Rumors",url:"https://www.tomshardware.com/news/amd-ryzen-3000-everything-we-know,38233.html"},{label:"Titan RTX Review",url:"https://www.tomshardware.com/reviews/nvidia-titan-rtx-deep-learning-gaming-tensor,5971.html"},{label:"Cheap Windows 10",url:"https://www.tomshardware.com/reviews/get-windows-10-free-or-cheap,5717.html"},
{label:"Ultimate RGB PC",url:"https://www.tomshardware.com/reviews/rgb-everything-pc-build,5964.html"}],f="Trending",c='<style>.trending-wrapper { margin: 0 auto; padding:10px 0; background: white;display: block; font-weight: 600; max-width: 1440px;text-align: left; font-family: Lato,"Open Sans","Source Sans Pro",Arial;} .trending-wrapper .trending-bar { overflow: hidden; *zoom: 1; display: block; background-color: transparent; position: relative; clear: both; width: 100%; height: 40px; font-size: 14px; background: #ededed; } .trending-wrapper .trending-lead { text-transform: uppercase; margin: 0 0 0 10px; padding: 0 25px 0 0; display: inline-block; line-height: 40px; position: relative; cursor: pointer; background: #ededed; \tvertical-align:top;    color: #be3806; } .trending-wrapper .trending-items { overflow: hidden; height: 100%; display: inline-block; max-width: 85%; \tmargin: 0; padding: 0; } .trending-lead:after, .trending-lead:before { left: 88%; top: 18%; border: solid transparent; content: " "; height: 0; width: 0; position: absolute; pointer-events: none; } .trending-lead::before { border-color: transparent transparent transparent #fff; border-width: 22px; margin-top: -11px; } .trending-lead::after { border-color: transparent; border-left-color: #ededed; border-width: 19px; margin-top: -8px; } .trending-wrapper .trending-item { display: inline-block; *display: inline; margin-left: -2px; line-height: 40px; } .trending-wrapper .trending-item a { line-height: 40px; padding: 0 14px; display: block; \tcolor: black; }</style>';
$head=document.querySelector("head");$head.insertAdjacentHTML("beforeend",c);var d="#header_leaderboard, #topAd",c=".page.header-container, .mainHeader.header-main";if(d=document.querySelector(d)){$target=d;position="afterend"}else{$target=document.querySelector(c);position="afterend"}var e="";b.forEach(function(a){if(a.label&&a.url)e+='<li class="trending-item"><a class="trending-item-link" href="'+a.url+'">'+a.label+"</a></li>"});b='<div class="trending-wrapper moboff">'+'\t\t\t<div class="trending-bar container full">'+
'\t\t\t\t<div class="trending-lead">'+f+"</div>"+'\t\t\t\t<ul class="trending-items brands-enabled">'+e+"\t\t\t\t</ul>"+"\t\t\t</div>"+"\t\t</div>";if($target)$target.insertAdjacentHTML(position,b)}();
} catch (e) {
console.error(e);
}
try {
tmntag_ready(function() {

(function(b){var a="US GB CA AU FR";if(!a.includes("NL")){console.log("RAMP -- disallowed country for JW "+"NL");return}for(x in tmntag.pubtargets)if(tmntag.pubtargets[x][0]==="vplid"){a=tmntag.pubtargets[x][1];b.playlistId=a;break}var a=function(){if(!window.Purch.Jwplayer){console.log("-RAMP Video- window.Purch.Jwplayer is ",window.Purch.Jwplayer);return}var a=function(){setTimeout(function(){if(window.require)window.Purch.JwplayerInstance=new window.Purch.Jwplayer(b);
else a()},1E3)};b.checkRequire=b.checkRequire.indexOf("${")<0&&b.checkRequire!=="0";if(b.checkRequire!==false){console.log("-RAMP Video- checkRequire");a()}else{console.log("-RAMP Video- new Jwplayer");window.Purch.JwplayerInstance=new window.Purch.Jwplayer(b)}},c=document.createElement("script");c.onload=a;document.head.appendChild(c);c.src="https://assets.purch.com/ramp/prod/assets/jwplayer/JWPlayer.js?v=1.17.0&t"+Date.now()})({gaAccount:"UA-72111741-12",playlistTargetHandler:"${PAGE:JW_PLAYLIST_TARGET_HANDLER}",
playlistTarget:".content > p:nth-of-type(3), .content > article:first-child > p:nth-of-type(3),.listing-page .listing-item:nth-of-type(2), .thread > .more-about, .page-content > .page-content-onecol > .widget-area-group-2col .widget-content-parsed p:nth-of-type(3), .zonepub6",playerId:"${PAGE:JW_PLAYER_ID}",playlistId:"67Yco6KI",playerLicenseKey:"NLVTwYKe5kBs2O1ZEZFGvVo1Y44MJtPAymTh/PhEGb7r7GUh",playerSrc:"https://assets.purch.com/ramp/assets/jwplayer/jwplayer-8.2.3-self-hosted.js",rightRail:"${PAGE:JW_RIGHT_RAIL}",recommendationsURL:"https://cdn.jwplayer.com/v2/playlists/SBxcyjkG?related_media_id=pFbH0SiL",container:"#ctBoc > .page, .body-section > .page, .tguContent",settings:"${PAGE:JW_PLAYER_SETTINGS}",bidderID:"176310",device:window.Purch&&Purch.cs_data&&Purch.cs_data.device||"Computer",checkRequire:"0",
customStyles:"${PAGE:JW_CUSTOM_STYLE}"});

});
} catch (e) {
console.error(e);
}
try {
if(typeof tmntag!=="undefined"&&tmntag&&tmntag.video)tmntag.video.triggerErrorEventEnabled=true;
} catch (e) {
console.error(e);
}
try {
try{var _facebookId="${PAGE_DOMAIN:FACEBOOK_ID}";if(typeof fbq==="undefined"){!function(b,e,f,g,a,c,d){if(_facebookId==""||_facebookId.indexOf("$")==0)return;if(b.fbq)return;a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)};if(!b._fbq)b._fbq=a;a.push=a;a.loaded=!0;a.version="2.0";a.queue=[];c=e.createElement(f);c.async=!0;c.src=g;d=e.getElementsByTagName(f)[0];d.parentNode.insertBefore(c,d)}(window,document,"script","//connect.facebook.net/en_US/fbevents.js");
if(window.fbq){fbq("init",_facebookId);fbq("track","PageView")}}}catch(b){console.log(b)};
} catch (e) {
console.error(e);
}
try {
window.CONFIANT_WRAPPER_ID="bVZ2FLsqHB_T8Sl1y-8ASj3X0Zk";
window.confiantWrapWithCallback=function(e,a,t,g,u){function l(b){return(m(b)||"")[n]("/","_")[n]("+","-")}function v(b,c,a){b=w+p(b)+"&d="+c;c="err__"+1*new Date;d[c]=a;a="<"+f+" on"+x+'="void('+c+'())" '+y+'="'+b+'" type="text/java'+f+'" ></'+f+">";e[q](a)}function z(){var b=l(g+"/"+k.k.hb_bidder[0]+":"+k.k.hb_size[0]),c={wh:b,wd:h.parse(h[r](k)),wr:0};v(b,l(h[r](c)),function(){e[q](a.ad)});var f={prebid:{adId:a.adId,cpm:a.cpm}},c={d:c,t:a.ad,cb:u,id:f};d[g]={},d[g][b]=c}var A=a.bidder,B=a.size,
d=e.parentWindow||e.defaultView,h=d.JSON,m=d.btoa,p=d.encodeURIComponent;if(!h||!m)return!1;var C="t",D="i",f="script",y="src",n="replace",x="error",r="stringify",q="wr"+D+C+"e",w="https://"+t+"/?wrapper="+p(g)+"&tpid=",k={k:{hb_bidder:[A],hb_size:[B]}};return z(),e.close(),!0};
} catch (e) {
console.error(e);
}
try {
tmntag_adlabel={};tmntag_adlabel.getLabelInfoFromAdunit=function(b){b=tmntag_getAdunitFromCache(b);if(!b)return null;b=b.label;if(!b)return false;var a={};a.ad_label_display=true;a.ad_label_style=b.style;a.ad_label_position=b.position;return a};tmntag_adlabel.getLabelParams=function(b){var a=tmntag.getAdParameters(b);if(a&&a.ad_label_display)return a;else if((a=tmntag_adlabel.getLabelInfoFromAdunit(b))&&a.ad_label_display)return a;else return{ad_label_display:true}};
tmntag_adlabel.setStyle=function(b,a){var c=tmntag_adlabel.getLabelParams(b);a.className="tmntag_adlabel";a.innerHTML="Advertisement";a.setAttribute("data-target",b);b=c&&c.ad_label_bg_color||"#FFFFFF";var d=c&&c.ad_label_color||"rgb(0,0,0,0.5)";a.style.setProperty("background-color",b,"important");a.style.setProperty("color",d,"important");a.style.padding="0px 2px 0px 2px";a.style.setProperty("display","block","important");a.style.setProperty("font-size","10px","important");a.style.setProperty("line-height",
"10px","important");if(c&&c.ad_label_display=="report")a.innerHTML="Advertisement";b=c&&c.ad_label_style;if(c&&b){b=b.trim().split(";");for(c=0;c<b.length;c++){if(b[c]==="")continue;style=b[c].trim().split(":");d=null;if(!style[1])continue;if(style[1].indexOf("!important")>0){style[1]=style[1].replace("!important","");d="important"}a.style.setProperty(style[0].trim(),style[1].trim(),d)}}return a};
tmntag_adlabel.adLabelTopCenter=function(b,a){a=document.getElementById(b);if(!a)return;var c=document.createElement("div");c.style.textAlign="center";c=tmntag_adlabel.setStyle(b,c);a.insertBefore(c,a.childNodes[0])};tmntag_adlabel.adLabelBottomCenter=function(b,a){a=document.getElementById(b);var c=document.createElement("div");c.style.textAlign="center";c=tmntag_adlabel.setStyle(b,c);a.appendChild(c)};
tmntag_adlabel.render=function(b,a){var c=tmntag_adlabel.getLabelParams(b);if(typeof c=="undefined"||!c)return;if(document.getElementById(b).firstChild.className==="tmntag_adlabel")return;if(c.ad_label_display)if(c.ad_label_position==="top_center")tmntag_adlabel.adLabelTopCenter(b,a);else if(c.ad_label_position==="bottom_center")tmntag_adlabel.adLabelBottomCenter(b,a)};
} catch (e) {
console.error(e);
}
try {
function ssJSCodeWrapper(){}function ssJSImmediator(){if(typeof window.ssJSConnWriteCookies==="function")window.ssJSConnWriteCookies();else{window.ss_uzjs_ssresp=0;window.ss_uzjs_datasent=true;ssJSCodeWrapper()}}
(function(a,d,e,f,g,h,k,b,c){a.SSJSConnectorObj=a.SSJSConnectorObj||{ss_cid:g,domain_info:h};a.ss_uzjs_datasent=a.ss_uzjs_datasent||false;b=d.createElement(e);b.async=true;b.src=f;c=d.getElementsByTagName(e)[0];c.parentNode.insertBefore(b,c);if(typeof setTimeout==="function")setTimeout(ssJSImmediator,k);else{window.ss_uzjs_ssresp=0;window.ss_uzjs_datasent=true;ssJSCodeWrapper()}})(window,document,"script","https://cdn.perfdrive.com/aperture/spectrum.js","88f4","auto",2E3);
} catch (e) {
console.error(e);
}
try {
(function(){var a,c,b;c=false;if(window.DigiTrust)return;a=document.createElement("script");a.type="text/javascript";a.src="https://cdn.digitru.st/prod/1/digitrust.min.js";a.onload=a.onreadystatechange=function(){if(!c&&(!this.readyState||this.readyState==="complete")){c=true;var a="${PAGE_DOMAIN:DIGITRUST_MEMBER_ID}",b="${PAGE_DOMAIN:DIGITRUST_SITE_ID}";if(a.indexOf("$")===0)a="v46nlNRxd9";if(b.indexOf("$")===0)b="qjWen4BfnB";DigiTrust.initialize({member:a,site:b},function(a){})}};b=document.getElementsByTagName("script")[0];
b.parentNode.insertBefore(a,b)})();
} catch (e) {
console.error(e);
}
try {
(function(){var c=window.gtmDataLayer||window.dataLayer||[],d=document.getElementById("footer-newsletter"),e=false,f=document.getElementById("right-rail-newsletter"),g=false,h=document.getElementById("homepage-newsletter"),k=false,l=document.getElementById("end-of-article-newsletter"),m=false;window.addEventListener("scroll",function(){{if(f&&b(f)&&!g){c.push({event:"Newsletter: right-rail",action:"impression"});g=true}}{if(d&&b(d)&&!e){c.push({event:"Newsletter: footer",action:"impression"});e=true}}{if(h&&
b(h)&&!k){c.push({event:"Newsletter: homepage",action:"impression"});k=true}}{if(l&&b(l)&&!m){c.push({event:"Newsletter: end of article",action:"impression"});m=true}}},false);var b=function(a){a=a.getBoundingClientRect();return a.top>=0&&a.left>=0&&a.bottom<=(window.innerHeight||document.documentElement.clientHeight)&&a.right<=(window.innerWidth||document.documentElement.clientWidth)},n=document.querySelectorAll("#footer-newsletter, #homepage-newsletter, #right-rail-newsletter");n.forEach(function(a,
b){a.onsubmit=function(){if(a.id){var b="Newsletter: "+a.id.split("-newsletter")[0];c.push({event:b,action:"submit"})}}})})();
} catch (e) {
console.error(e);
}
try {
tmntag_ready(function() {

function ucFunnelPixel(){try{var b=Math.floor(Math.random()*11E3),c=document.location.protocol==="https:"?"https":"http",a=new Image(0,0);a.src="//sync.aralego.com/idSync/?ucf_nid=par-2EE948B3EA8B6A90994284DE3BE42B&ucf_user_id=0d8866a42f2f49e3ae0ef55f5cbfe033&redirect="+c+"%3A%2F%2Fpixel.servebom.com%2Fpartner%3Fcd%3D"+b+"%26svc%3Dus%26id%3D31%26uid%3DUCFUID";document.body.appendChild(a)}catch(d){console.error(d)}}
if(window.tmntag&&typeof tmntag.executeWithGDPRConsent==="function")tmntag.executeWithGDPRConsent(undefined,ucFunnelPixel);else if(typeof window.purchs2s_executeWithGDPRConsent==="function")window.purchs2s_executeWithGDPRConsent(ucFunnelPixel);else ucFunnelPixel();

});
} catch (e) {
console.error(e);
}
try {
(function(){var a=document.createElement("script");a.type="text/javascript";a.async=true;a.src="https://get.s-onetag.com/1b18796b-55b2-408e-8178-fa56acfec0c5/tag.min.js";var b=document.getElementsByTagName("script")[0];b.parentNode.insertBefore(a,b)})();
} catch (e) {
console.error(e);
}
try {
tmntag_ready(function() {

(function(){function d(a){e(function(){__cmp("addEventListener","cmpReady",a)})}function f(){if(Purch.AdTech.cmpQueue.length>0)for(;Purch.AdTech.cmpQueue.length>0;){var a=Purch.AdTech.cmpQueue.shift();if(typeof a==="function")a();else switch(a){case "consentAll":Purch.AdTech.consentAll()}}Purch.AdTech.cmpQueue.push=function(a){Array.prototype.push.call(Purch.AdTech.cmpQueue,a);f()}}function g(a){var c=document.createElement("iframe");c.src="https://ads.servebom.com/add_cookies?key=euconsent&value="+
a;c.style.display="none";document.body.appendChild(c)}function h(a,c){if(k)return;k=true;a=a||{};c=c||{};a=a.vendorListVersion;var b=c.created,d=c.vendorListVersion;if((!b||a&&d!==a)&&Purch.AdTech.showGDPRBanner)Purch.AdTech.showGDPRBanner();else if(b)g(c.metadata)}function l(){var a=window,c=a.tmntag,b=a.purchs2s;return a.gdprMode==="PIITrackingWithConsent"||c&&c.getPersonalizedAdsMode&&c.getPersonalizedAdsMode()==="managed"||b&&b.getPersonalizedAdsMode&&b.getPersonalizedAdsMode()==="managed"}window.Purch=
window.Purch||{};Purch.AdTech=Purch.AdTech||{};Purch.AdTech.cmpQueue=Purch.AdTech.cmpQueue||[];var e=window.tmntag_waitForCMP||purchs2sutils._waitForCMP;Purch.AdTech.showCMPModal=function(){d(function(){__cmp("showConsentTool",1)})};Purch.AdTech.consentAll=function(){d(function(){__cmp("consentAll")})};Purch.AdTech.onConsent=function(a){e(function(){__cmp("addEventListener","onSubmit",a)})};Purch.AdTech.onClose=function(a){e(function(){__cmp("addEventListener","onClose",a)})};var k=false,b="${PAGE_DOMAIN:GDPR_STORE_CONSENT_GLOBALLY}";
if(b===""||b.indexOf("$")===0)b=true;else b=b!=="false";if(l()){window.__cmp=window.__cmp||{};window.__cmp.config={globalVendorListLocation:"https://purch.mgr.consensu.org/vendorlist.json",globalConsentLocation:"https://purch.mgr.consensu.org/portal.html",customPurposeListLocation:"https://purch.mgr.consensu.org/purposes.json",storePublisherData:false,storeConsentGlobally:b};b=document.createElement("script");b.async=true;b.addEventListener("load",function(){e(function(){window.__cmp("addEventListener",
"onSubmit",function(){__cmp("getConsentData",null,function(a){g(a.consentData)})})});d(function(){__cmp("getVendorList",null,function(a){var b=window.setTimeout(function(){h(a)},100);__cmp("getVendorConsents",null,function(c){window.clearTimeout(b);h(a,c)})})});d(f)});b.src="https://purch.mgr.consensu.org/cmp.bundle.js";document.body.appendChild(b)}})();

});
} catch (e) {
console.error(e);
}
